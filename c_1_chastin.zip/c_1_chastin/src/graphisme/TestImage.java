package graphisme;

public class TestImage {
	
	public static void main(String[] args) {
		Sprite.getAlien();
	}
}
